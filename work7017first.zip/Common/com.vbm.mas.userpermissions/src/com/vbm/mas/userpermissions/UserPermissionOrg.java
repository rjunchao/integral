package com.vbm.mas.userpermissions;

import org.gocom.components.coframe.org.dataset.impl.OrgOrganizationImpl;

public class UserPermissionOrg extends OrgOrganizationImpl {

}
