package com.pub.xbkj.pubapp;

public enum JavaType
{
  String, BigDecimal, Integer, Float,Double, Boolean, Date, Object, BLOB;
}