package com.pub.xbkj.pubapp.converter;

public abstract interface Converter
{
  public abstract Object convert(Object paramObject, Class<?> paramClass);
}